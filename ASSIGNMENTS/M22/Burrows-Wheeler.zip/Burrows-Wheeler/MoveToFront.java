
public class MoveToFront {

    public static void encode() {

    }

    public static void decode() {

    }

    public static void main(String[] args) {

    }
}
