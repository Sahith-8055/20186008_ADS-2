

public class BurrowsWheeler {


    public static void transform() {

    }

    public static void inverseTransform() {
    }

    public static void main(String[] args) {

    }
}
