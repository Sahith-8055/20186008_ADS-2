public class CircularSuffixArray {


    public CircularSuffixArray(String s) {
    }

    public int length() {
    	return 0;
    }

    /**
     * returns index of ith sorted suffix
     *
     * @param i
     *            the index of the ith sorted suffix
     * @return
     */
    public int index(int i) {
    	return 0;
    }

}
